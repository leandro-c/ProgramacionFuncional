import Tribu

-- Como usuario:

-- Precondicion: hay n jovenes
dropNMasJoven :: Int -> Tribu -> Tribu
-- Precondicion :: hay por lo menos una persona
elMasViejo :: Tribu -> Persona
mapearEdades :: Tribu -> Map Persona Int