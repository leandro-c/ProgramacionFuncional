#include <iostream>
#include <stdlib.h>

using namespace std;

void printBool(bool b);
void printRespuesta(bool b);

#define BOOM(str) { cout << "ERROR: " << str << endl; exit(1); }

bool esPar(int x);
//bool max(int x, int y);

