#include "Pairs.h"

Pair padd(Pair p1, Pair p2);
float  distance(Pair p);

/* TESTING */
void testingPairs(Pair p);
