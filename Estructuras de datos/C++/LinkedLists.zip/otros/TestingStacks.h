#include "Prelude.h"
#include "Stack.h"

Bool balance(char* str);

/* TESTING */
void testingStacks();


